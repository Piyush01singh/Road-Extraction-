from sklearn.metrics import accuracy_score

preds = model.predict(X_test)
acc = accuracy_score(y_test, preds)
print("Validation Accuracy:", acc)
train_acc = model.score(X_train, y_train)
print("Training Accuracy:", train_acc)
