from xgboost import XGBClassifier

model = XGBClassifier(
    n_estimators=100,
    learning_rate=0.1,
    use_label_encoder=False,
    eval_metric='logloss'
)
print("Training model...")
model.fit(X_train, y_train)
print("✓ Training complete.")
