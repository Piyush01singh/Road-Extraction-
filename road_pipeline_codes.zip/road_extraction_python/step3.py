from sklearn.preprocessing import MinMaxScaler
from scipy import stats
import numpy as np

z_scores = stats.zscore(df[['r','g','b']])
abs_z = np.abs(z_scores)
df = df[(abs_z < 3).all(axis=1)]

scaler = MinMaxScaler()
cols = ['r','g','b','texture']
df[cols] = scaler.fit_transform(df[cols])
print(f"✓ Preprocessing Complete. {df.shape[0]} samples remain.")
