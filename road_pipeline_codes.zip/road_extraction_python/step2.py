# Display DataFrame information
print("--- DataFrame Info ---")
print(df.info())

missing_counts = df.isnull().sum()
if missing_counts.sum() > 0:
    print("\nMissing Values Found:\n", missing_counts[missing_counts > 0])
else:
    print("\n✓ No missing values detected.")

print("\n--- Descriptive Statistics ---")
print(df[['r','g','b','ndvi']].describe().T)
