import pandas as pd
import numpy as np
import os

DATA_PATH = 'satellite_data.csv'

if os.path.exists(DATA_PATH):
    df = pd.read_csv(DATA_PATH)
    print("✓ Dataset Loaded Successfully")
    print(f"Shape: {df.shape}")
    print(f"Columns: {list(df.columns)}")
else:
    print(f"Error: {DATA_PATH} not found.")


# Display DataFrame information
print("--- DataFrame Info ---")
print(df.info())

missing_counts = df.isnull().sum()
if missing_counts.sum() > 0:
    print("\nMissing Values Found:\n", missing_counts[missing_counts > 0])
else:
    print("\n✓ No missing values detected.")

print("\n--- Descriptive Statistics ---")
print(df[['r','g','b','ndvi']].describe().T)


from sklearn.preprocessing import MinMaxScaler
from scipy import stats
import numpy as np

z_scores = stats.zscore(df[['r','g','b']])
abs_z = np.abs(z_scores)
df = df[(abs_z < 3).all(axis=1)]

scaler = MinMaxScaler()
cols = ['r','g','b','texture']
df[cols] = scaler.fit_transform(df[cols])
print(f"✓ Preprocessing Complete. {df.shape[0]} samples remain.")


import seaborn as sns
import matplotlib.pyplot as plt

plt.figure(figsize=(12,5))
plt.subplot(1,2,1)
sns.kdeplot(data=df, x='g', hue='isRoad', fill=True, palette='viridis')
plt.title('Green Channel Intensity: Road vs Non-Road')

plt.subplot(1,2,2)
sns.countplot(x='isRoad', data=df, palette='coolwarm')
plt.title('Target Class Distribution')
plt.tight_layout()
plt.show()


from sklearn.feature_selection import SelectKBest, f_classif
import pandas as pd

X = df.drop(['id','isRoad'], axis=1)
y = df['isRoad']
selector = SelectKBest(score_func=f_classif, k='all')
X_new = selector.fit_transform(X, y)
scores = pd.DataFrame({'Feature': X.columns, 'Score': selector.scores_})
print(scores.sort_values(by='Score', ascending=False))


from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y)

print("Training Set:", X_train.shape)
print("Testing Set:", X_test.shape)


from xgboost import XGBClassifier

model = XGBClassifier(
    n_estimators=100,
    learning_rate=0.1,
    use_label_encoder=False,
    eval_metric='logloss'
)
print("Training model...")
model.fit(X_train, y_train)
print("✓ Training complete.")


from sklearn.metrics import accuracy_score

preds = model.predict(X_test)
acc = accuracy_score(y_test, preds)
print("Validation Accuracy:", acc)
train_acc = model.score(X_train, y_train)
print("Training Accuracy:", train_acc)


probs = model.predict_proba(X_test)[:,1]
import pandas as pd

results = pd.DataFrame({
    'Actual': y_test,
    'Predicted': preds,
    'Confidence': probs
})

uncertain = results[(results['Confidence'] > 0.4) & (results['Confidence'] < 0.6)]
print("Uncertain Predictions:\n", uncertain.head())


from sklearn.metrics import classification_report, confusion_matrix
import seaborn as sns
import matplotlib.pyplot as plt

print("--- Classification Report ---")
print(classification_report(y_test, preds, target_names=['Non-Road','Road']))

cm = confusion_matrix(y_test, preds)
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues')
plt.xlabel('Predicted')
plt.ylabel('Actual')
plt.show()


from sklearn.metrics import roc_curve, auc
import matplotlib.pyplot as plt

fpr, tpr, th = roc_curve(y_test, probs)
roc_auc = auc(fpr, tpr)

plt.figure(figsize=(8,6))
plt.plot(fpr, tpr, color='darkorange', lw=2, label=f"AUC={roc_auc:.2f}")
plt.plot([0,1],[0,1], linestyle='--', color='navy')
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC Curve')
plt.legend()
plt.show()
