import pandas as pd
import numpy as np
import os

DATA_PATH = 'satellite_data.csv'

if os.path.exists(DATA_PATH):
    df = pd.read_csv(DATA_PATH)
    print("✓ Dataset Loaded Successfully")
    print(f"Shape: {df.shape}")
    print(f"Columns: {list(df.columns)}")
else:
    print(f"Error: {DATA_PATH} not found.")
