probs = model.predict_proba(X_test)[:,1]
import pandas as pd

results = pd.DataFrame({
    'Actual': y_test,
    'Predicted': preds,
    'Confidence': probs
})

uncertain = results[(results['Confidence'] > 0.4) & (results['Confidence'] < 0.6)]
print("Uncertain Predictions:\n", uncertain.head())
