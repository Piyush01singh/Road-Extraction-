import seaborn as sns
import matplotlib.pyplot as plt

plt.figure(figsize=(12,5))
plt.subplot(1,2,1)
sns.kdeplot(data=df, x='g', hue='isRoad', fill=True, palette='viridis')
plt.title('Green Channel Intensity: Road vs Non-Road')

plt.subplot(1,2,2)
sns.countplot(x='isRoad', data=df, palette='coolwarm')
plt.title('Target Class Distribution')
plt.tight_layout()
plt.show()
