from sklearn.feature_selection import SelectKBest, f_classif
import pandas as pd

X = df.drop(['id','isRoad'], axis=1)
y = df['isRoad']
selector = SelectKBest(score_func=f_classif, k='all')
X_new = selector.fit_transform(X, y)
scores = pd.DataFrame({'Feature': X.columns, 'Score': selector.scores_})
print(scores.sort_values(by='Score', ascending=False))
